package it.impiegati;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P20250325ImpiegatiApplication {

	public static void main(String[] args) {
		SpringApplication.run(P20250325ImpiegatiApplication.class, args);
	}

}
