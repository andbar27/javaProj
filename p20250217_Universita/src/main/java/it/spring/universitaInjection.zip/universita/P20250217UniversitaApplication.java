package it.spring.universita;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P20250217UniversitaApplication {

	public static void main(String[] args) {
		SpringApplication.run(P20250217UniversitaApplication.class, args);
	}

}
