package p20241122_Test_ProductApp;

import java.util.List;

public interface Ordinable {
	
	public List<Prodotto> sortByPrice(List<Prodotto> products);

}
