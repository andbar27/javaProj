package p20241122_Test_Regine;

public class Tupla {
	int x;
	int y;
	
	public Tupla(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}
}
