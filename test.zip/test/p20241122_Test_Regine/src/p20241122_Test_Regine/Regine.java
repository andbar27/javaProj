package p20241122_Test_Regine;

import java.util.HashMap;

public class Regine {
	
	public static void rey(int[][] square, int x, int y, int x1, int y1) {
		if(x != x1 && y != y1 && )
		
		
		
	}
	
	public static void reset(int[][] square) {
		for(int i=0; i < square.length; i++)
			for(int j=0; j<square.length; j++)
				square[i][j]=0;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] square = new int[8][8];
		
		for(int i=0; i < square.length; i++)
			for(int j=0; j<square.length; j++)
				square[i][j]=0;
		
		square[0][0] = 1;

	}


	

}
