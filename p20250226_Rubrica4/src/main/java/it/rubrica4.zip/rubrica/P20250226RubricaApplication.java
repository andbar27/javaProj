package it.rubrica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P20250226RubricaApplication {

	public static void main(String[] args) {
		SpringApplication.run(P20250226RubricaApplication.class, args);
	}

}
