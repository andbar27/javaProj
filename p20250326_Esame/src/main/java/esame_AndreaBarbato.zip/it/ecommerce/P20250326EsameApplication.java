package it.ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P20250326EsameApplication {

	public static void main(String[] args) {
		SpringApplication.run(P20250326EsameApplication.class, args);
	}

}
