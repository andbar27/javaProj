
public interface Specs {
	public String GetVersion();
	public String GetDate();

}
