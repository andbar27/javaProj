
public abstract class EssereVivente {
	protected String coloreOcchi;
	
	protected abstract void SetColoreOcchi();
	
	public abstract String GetColoreOcchi();

}
